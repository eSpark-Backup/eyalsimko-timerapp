package com.example.eyal_controltimer;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import java.util.ArrayList;

public class DialogConnecting {

    public interface DialogConnectingMethods{
        void onConnect(String wifi, String password);
        void scanWifi();
        void scanQRCode();
        void shutdown();
    }

    private static final int DROPDOWN_TEXTSIZE = 16;
    DialogConnectingMethods methods = null;
    Context c;
    private Dialog dialog;

    private TextView txtSearching, txtConnecting, txtOpenWebsocket;
    private Button btnConnect, btnScanWifi, btnScanQRCode;
    private ImageButton btnHelp, btnClose;
    private Spinner spnWifis;
    private EditText edtPassword;
    private boolean _isShowing = false;

    public DialogConnecting(Context c, DialogConnectingMethods methods){
        this.methods = methods;
        this.c = c;
        dialog = new Dialog(c);
        dialog.setContentView(R.layout.dlg_connecting);
        //set the dialog background to transparent so you only see the constraint layout background
        //the problem was that the constraint was rounded but the actual dialog had square corners
        //dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        //TODO take this out
        dialog.setCancelable(true);

        //txtSearching = dialog.findViewById(R.id.lblWifiFound);
        btnConnect = dialog.findViewById(R.id.btnConnectToTimer);
        btnScanWifi = dialog.findViewById(R.id.btnRescan);
        btnClose = dialog.findViewById(R.id.imgConnectingClose);
        btnScanQRCode = dialog.findViewById(R.id.btnScanQRCode);
        btnHelp = dialog.findViewById(R.id.imgConnectingHelp);
        txtConnecting = dialog.findViewById(R.id.lblConnection_Connecting);
        edtPassword = dialog.findViewById(R.id.edtWifiPassword);
        txtOpenWebsocket = dialog.findViewById(R.id.lblConnection_OpenWebsocket);
        spnWifis = dialog.findViewById(R.id.spnWifi);


        txtConnecting.setVisibility(View.INVISIBLE);
        txtOpenWebsocket.setVisibility(View.INVISIBLE);

        btnConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String wifiName = spnWifis.getSelectedItem().toString();
                String wifiPassword = edtPassword.getText().toString();

                if (methods != null){
                    methods.onConnect(wifiName, wifiPassword);
                }
            }
        });
        btnScanWifi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (methods != null){
                    methods.scanWifi();
                }
            }
        });

        btnScanQRCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (methods != null){
                    methods.scanQRCode();
                }
            }
        });

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               dialog.cancel();
            }
        });

        btnHelp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String msg = "If you do not see any Timer Modules in the drop down, wait a few seconds and press \"Scan Wifi\".\n" +
                        "\nIf you still don't see any after repeating that process, reset your wifi and try again.";
                new AlertDialog.Builder(c)
                        .setTitle("Troubleshooting")
                        .setMessage(msg)
                        .setPositiveButton("Ok", (dialog, which) -> {

                        })
                        .create()
                        .show();
            }
        });
    }

    public void setEdtPassword(String psd){
        edtPassword.setText(psd);
    }
    public void setMethods(DialogConnectingMethods methods){
        this.methods = methods;
    }
    public void setWifiNetworks(ArrayList<String> networks){

        ArrayAdapter adpWifi = new ArrayAdapter(c,android.R.layout.simple_list_item_1,networks){
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                // Get the view for the currently selected item in the Spinner
                View view = super.getView(position, convertView, parent);

                // Customize the text size
                TextView textView = (TextView) view.findViewById(android.R.id.text1);
                textView.setTextSize(DROPDOWN_TEXTSIZE); // Set your desired text size here (e.g., 18sp)

                return view;
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                // Get the view for the dropdown list items
                View view = super.getDropDownView(position, convertView, parent);

                // Customize the text size
                TextView textView = (TextView) view.findViewById(android.R.id.text1);
                textView.setTextSize(DROPDOWN_TEXTSIZE); // Set your desired text size here (e.g., 18sp)

                return view;
            }
        };
        spnWifis.setAdapter(adpWifi);
    }

    public void show( ){
        dialog.show();
        _isShowing = true;
    }

    public void close(){
        dialog.cancel();
        _isShowing = false;
    }

    public boolean isShowing(){
        return _isShowing;
    }

    public void showOpenWebsocket(){
        txtOpenWebsocket.setVisibility(View.VISIBLE);
    }
    private void hideOpenWebsocket(){
        txtOpenWebsocket.setVisibility(View.INVISIBLE);
    }

    public void showConnecting(){
        txtConnecting.setVisibility(View.VISIBLE);
    }
    private void hideConnecting(){
        txtConnecting.setVisibility(View.INVISIBLE);
    }

    public void hideTexts(){
        hideConnecting();
        hideOpenWebsocket();
    }



}
