package com.example.eyal_controltimer;

/*
This app connects to RPI Access Point via Wifi or USB-C->Ethernet adapter

To connect via ethernet, phone must be in Airplane mode because otherwise it will
prioritize wifi or mobile data.


RPI Screen is 3840x1100

--Commands Sent--
reset:*time in seconds* - reset the clock on the screen to new time
blink:*time in seconds* - send the time that the blinkers should start
msg:*message to show* - sends message to show on screen instead of timer
hide - hides the message and shows the timer again
start - start initial timer
pause - pause timer
resume
stop



TODO
check if the wifi is disabled and turn it on if it is
search for all available wifi networks and filter to the one with OneUp-A2B4D3

Still To Complete
Help page
Enclosure





 */

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.NetworkRequest;
import android.net.Uri;
import android.net.wifi.ScanResult;
import android.net.wifi.SupplicantState;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiNetworkSpecifier;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;


import com.example.eyal_controltimer.databinding.ActivityMainBinding;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

public class MainActivity extends AppCompatActivity {

    private static final double VERSION_NUM = 1.1;
    private static final String TAG = "USER_DEV";
    //private static final String WIFI_SSID = "ControlTimerABC";
    private static final String WIFI_PREFIX = "TOUG-";
   // private static final String WIFI_PREFIX = "ControlTimer";
    private static final String WIFI_PASS = "123456789";
    //private static final String WEBSOCKET_ADD = "ws://controltimerabc.local:8001/ws";
    private static final String WEBSOCKET_WIFI_ADD = "ws://192.168.4.1:8001/ws";
    private static final String WEBSOCKET_ETH0_ADD = "ws://192.168.0.1:8001/ws";
    private ActivityMainBinding binding;
    private static final int REQUEST_PERMISSIONS = 1;
    private WifiManager wifiManager;
    private BroadcastReceiver wifiReceiver;
    private ConnectivityManager.NetworkCallback networkCallback;
    private ConnectivityManager connectivityManager;
    private DataViewModel data;
    private DialogConnecting dlgConnecting;
    private Menu menu_main;
    int co = 0;
    private int idxTimer = 0;
    private ctTimer curTimer = null;
    private Timer timer;
    private TimerTask timerTask;
    private int countdownSeconds = 0;
    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable countdownRunnable;
    private boolean isTimerRunning = false;
    private TextView toolbarText;
    private String msg_for_speaker = "Time is up!";
    private static final int MAX_MSG_LENGTH = 40;
    private DialogLoading dlgLoadingWired = null;
    //temp
    long timeSendStart, timeRecStart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = com.example.eyal_controltimer.databinding.ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Log the currently loaded layout
        String layoutName = getResources().getResourceEntryName(R.layout.activity_main);
        Log.d(TAG, "Loaded layout: " + layoutName);

        // Log the name of the layout being used
        logLayoutVersion();

        wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        data = new ViewModelProvider(this).get(DataViewModel.class);
        dlgConnecting = new DialogConnecting(this, new DialogConnecting.DialogConnectingMethods() {
            @Override
            public void onConnect(String wifi,String password) {

                if (wifi.isEmpty()){
                    data.showErrorDlg("No wifi selected. Try again.",MainActivity.this);
                    return;
                }

                if (password.isEmpty()){
                    data.showErrorDlg("No password entered. Try again.",MainActivity.this);
                }

                connectToWifi(wifi,password);
            }

            @Override
            public void scanWifi() {
                startWirelessConnection();
            }

            @Override
            public void scanQRCode() {
                Intent intent = new Intent(MainActivity.this, QRCodeScanner.class);
                startActivityForResult(intent, 1);

            }

            @Override
            public void shutdown() {
                data.sendWebMsg("shutdown");
            }
        });

        //data.deleteFiles(this);


        idxTimer = 0;
        binding.txtActiveTimer.setText("");
        binding.lblActiveTimerLabel.setText("");
        binding.edtShowMsg.setText(msg_for_speaker);
        //start and stop should be grayed out until you hit reset
        binding.btnStart.setEnabled(false);
        binding.btnStop.setEnabled(false);
        data.loadTimers(this);
        data.loadConfig(MainActivity.this);

        refreshScreen();


        checkPermissions();

        binding.txtCountdownTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //if this timer is currently running you can't change it
                if (curTimer != null && curTimer.equals(data.getTimers().get(idxTimer)) && timer != null) {
                    data.showErrorDlg("You can't edit a timer that is currently running!", MainActivity.this);
                    return;
                }


                DialogInputTime dlgInputTime = new DialogInputTime(MainActivity.this, new DialogInputTime.DialogInputTimeMethods() {
                    @Override
                    public void onConfirm(String time) {
                        //convert time to seconds and store it
                        int mins = Integer.parseInt(time.split(":")[0]);
                        int secs = Integer.parseInt(time.split(":")[1]);
                        int totalTime = (mins * 60) + secs;
                        data.getTimers().get(idxTimer).setTimeInSeconds(totalTime);
                        binding.txtCountdownTime.setText(time);
                        data.saveTimers(MainActivity.this);
                    }
                }, null);
            }
        });

        binding.txtBlinkStartTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogInputTime dlgInputTime = new DialogInputTime(MainActivity.this, new DialogInputTime.DialogInputTimeMethods() {
                    @Override
                    public void onConfirm(String time) {

                        //see if you changed the blink of the current timer
                        boolean isCurTimer = false;
                        if (curTimer != null && curTimer.equals(data.getTimers().get(idxTimer)) && timer != null) {
                            isCurTimer = true;
                        }
                        //convert time to seconds and store it
                        int mins = Integer.parseInt(time.split(":")[0]);
                        int secs = Integer.parseInt(time.split(":")[1]);
                        int totalTime = (mins * 60) + secs;
                        data.getTimers().get(idxTimer).setBlinkTime(totalTime);
                        binding.txtBlinkStartTime.setText(time);
                        data.saveTimers(MainActivity.this);

                        if (isCurTimer) {
                            data.sendWebMsg("blink:" + totalTime);
                        }

                    }
                }, null);
            }
        });

        binding.btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (idxTimer < data.getTimers().size()) {
                    idxTimer++;
                    refreshScreen();
                } else {
                    showToast("You are already at the end of the list");
                }
            }
        });

        binding.btnPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (idxTimer > 0) {
                    idxTimer--;
                    refreshScreen();
                } else {
                    showToast("You are already at the beginning of the list");
                }
            }
        });

        binding.btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //this function changes so grab the text to see what we clicked on
                String btnText = binding.btnStart.getText().toString();
                if (btnText.equals("Start")) {

                    //check that a timer has been selected
                    if (curTimer == null) {
                        data.showErrorDlg("Press reset to select the timer shown on the\ntop of the screen as the active timer", MainActivity.this);
                        return;
                    }

                    countdownSeconds = curTimer.getTimeInSeconds();
                    data.sendWebMsg("start");
                    timeSendStart = System.currentTimeMillis();
                    binding.btnStart.setText("Pause");
                    startTimer2();
                } else if (btnText.equals("Pause")) {
                    data.sendWebMsg("pause");
                    stopTimer2();
                    binding.btnStart.setText("Resume");
                } else if (btnText.equals("Resume")) {
                    data.sendWebMsg("resume");
                    startTimer2();
                    binding.btnStart.setText("Pause");
                }
            }
        });

        binding.btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //check that a timer has been selected
                if (curTimer == null) {
                    data.showErrorDlg("Press reset to select the timer shown on the\ntop of the screen as the active timer", MainActivity.this);
                    return;
                }

                data.sendWebMsg("stop");
                stopTimer2();
                curTimer = null;
                deselectTimer();

            }
        });

        binding.btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!data.openWebsocket.getValue()) {
                    data.showErrorDlg("Not connected to module. Please choose wireless or wired in the top bar to connect", MainActivity.this);
                    return;
                }

                //get current timer value, return if this timer hasnt been set yet
                curTimer = data.lstTimers.getValue().get(idxTimer);
                int timeOfCurrentTimer = curTimer.getTimeInSeconds();
                if (timeOfCurrentTimer == -1) {
                    data.showErrorDlg("The timer shown in the top of screen has not been set.\nPlease set the time before using this timer", MainActivity.this);
                    return;
                }


                data.sendWebMsg("reset:" + timeOfCurrentTimer);
                data.sendWebMsg("blink:" + curTimer.getBlinkTime());
                //stop current timer
                stopTimer2();
                //fill in the bottom of the screen with data from the current timer selected on the top
                //reset the active timer to black
                binding.txtActiveTimer.setTextColor(getResources().getColor(R.color.black));
                //set active timer text
                binding.txtActiveTimer.setText(data.secondsToText(timeOfCurrentTimer));
                //set active timer label
                binding.lblActiveTimerLabel.setText("Timer " + (idxTimer + 1) + ": " + curTimer.getLabel());
                //since we have selected a timer enable the start stop buttons
                binding.btnStart.setEnabled(true);
                binding.btnStop.setEnabled(true);
                //fix the start button text
                binding.btnStart.setText("Start");
            }
        });

        binding.edtSpeakerName.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                // Check if the action is the "Done" action
                if (actionId == EditorInfo.IME_ACTION_DONE ||
                        (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    // Call your custom function here
                    String speakerName = binding.edtSpeakerName.getText().toString();
                    Log.d(TAG, "Speaker name: " + speakerName);

                    if (!speakerName.isEmpty()) {
                        //store it in the current timer
                        data.getTimers().get(idxTimer).setLabel(speakerName);
                        //store data
                        data.saveTimers(MainActivity.this);
                    }
                    hideKeyboard();
                    binding.edtSpeakerName.clearFocus();
                    return true; // Return true if you handled the action
                }
                return false; // Return false if you did not handle the action
            }
        });

        binding.btnShowMsg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String btnText = binding.btnShowMsg.getText().toString();
                String msgToSend = binding.edtShowMsg.getText().toString();

                //check that this message is short enough
                if (msgToSend.length() >= MAX_MSG_LENGTH) {
                    data.showErrorDlg("The screen can only show a max of 40 characters.\nPlease make the message shroter.", MainActivity.this);
                    return;
                }

                if (msgToSend.isEmpty()) {
                    data.showErrorDlg("The message to show is blank, please fill in a message.", MainActivity.this);
                    return;
                }

                if (btnText.equals("Show Message")) {
                    data.sendWebMsg("msg:" + msgToSend);
                    binding.btnShowMsg.setText("Hide Message");
                    binding.edtShowMsg.setEnabled(false);
                    binding.edtShowMsg.setBackground(getResources().getDrawable(R.drawable.rounded_orange));
                } else {
                    data.sendWebMsg("hide");
                    binding.edtShowMsg.setEnabled(true);
                    binding.btnShowMsg.setText("Show Message");
                    binding.edtShowMsg.setBackground(null);

                }
            }
        });


    }

    private void startTimer2() {
        timer = new Timer();
        timerTask = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        countdownSeconds--;
                        updateCountdownText();
                    }
                });
            }
        };
        timer.scheduleAtFixedRate(timerTask, 200, 1000); // Schedule to run every 1 second
    }

    private void stopTimer2() {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    private void startTimer() {
        if (countdownRunnable != null) {
            handler.removeCallbacks(countdownRunnable);
        }

        countdownRunnable = new Runnable() {
            @Override
            public void run() {

                countdownSeconds--;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        updateCountdownText();
                    }
                });
                handler.postDelayed(this, 1000); // Schedule the next run after 1 second

            }
        };

        isTimerRunning = true;
        handler.post(countdownRunnable);
    }

    private void stopTimer() {
        if (countdownRunnable != null) {
            handler.removeCallbacks(countdownRunnable);
            countdownRunnable = null;
        }
        isTimerRunning = false;
    }

    private void updateCountdownText() {
        int timeToUse = countdownSeconds;
        if (timeToUse < 0) {
            timeToUse = -timeToUse;
        }
        int minutes = timeToUse / 60;
        int seconds = timeToUse % 60;
        String time = String.format("%02d:%02d", minutes, seconds);
        if (countdownSeconds > 0) {
            binding.txtActiveTimer.setTextColor(getResources().getColor(R.color.green));
        } else {
            binding.txtActiveTimer.setTextColor(getResources().getColor(R.color.red));
        }
        binding.txtActiveTimer.setText(time);
    }

    void refreshScreen() {
        //disable buttons at start and end of timer list
        if (idxTimer == data.getTimers().size() - 1) {
            binding.btnNext.setEnabled(false);
        } else {
            binding.btnNext.setEnabled(true);
        }

        if (idxTimer == 0) {
            binding.btnPrev.setEnabled(false);
        } else {
            binding.btnPrev.setEnabled(true);
        }

        ctTimer curTimer = data.getTimers().get(idxTimer);
        //set timer label at the top
        binding.txtTimerNum.setText("Timer " + (idxTimer + 1) + ":");
        binding.edtSpeakerName.setText(curTimer.getLabel());
        //update countdown time
        if (curTimer.getTimeInSeconds() == -1) {
            binding.txtCountdownTime.setText("Enter time");
            //binding.txtActiveTimer.setText("");
        } else {
            binding.txtCountdownTime.setText(data.secondsToText(curTimer.getTimeInSeconds()));
        }

        //update blink time
        if (curTimer.getBlinkTime() == -1) {
            binding.txtBlinkStartTime.setText("Enter time");
        } else {
            binding.txtBlinkStartTime.setText(data.secondsToText(curTimer.getBlinkTime()));
        }


    }

    void parseWebCMD(String cmd) {
        if (cmd.equals("hello")) {
            if (dlgConnecting.isShowing()) {
                dlgConnecting.close();
            }
            updateConnectionDot(true);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    data.openWebsocket.setValue(true);
                }
            });
            //send back the blink length
            data.sendWebMsg("blink_length:" + data.getConfig().getValue().getBlinkLength());
        }
        else if (cmd.contains("version")){

        } else if (cmd.equals("start")){

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    //startTimer2();
                    timeRecStart = System.currentTimeMillis();
                    Log.d(TAG, "Message delay: " + (timeRecStart - timeSendStart));
                }
            });
        }
    }

    private boolean checkWifiOn(){
        // Get the WifiManager system service
        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);

        if (wifiManager != null) {
            // Check if Wi-Fi is disabled
            if (wifiManager.isWifiEnabled()) {
                if (dlgConnecting.isShowing()) {
                    dlgConnecting.close();
                }
                return true;
            } else {
                //Toast.makeText(this, "Wi-Fi is already enabled.", Toast.LENGTH_SHORT).show();
                return false;
            }
        } else {
            Toast.makeText(this, "Unable to access Wi-Fi service.", Toast.LENGTH_SHORT).show();
        }

        return false;
    }
    private void startWirelessConnection(){

        ArrayList<String> networks = getListOfWifiNetworks();
        if (networks != null) {
            dlgConnecting.setWifiNetworks(networks);
            /*if (networks.size() == 0){
                data.showErrorDlg("No One Up Timer Modules found. Is the device powered on?",MainActivity.this);
            }*/

        }
    }

    private void showLoadingWired() {
        if (dlgLoadingWired == null) {
            dlgLoadingWired = new DialogLoading(this);
            dlgLoadingWired.setCancelable(true); // Prevent closing the dialog manually
            dlgLoadingWired.show();
        } else {
            dlgLoadingWired.show();
        }
    }

    private void dismissLoadingWired() {
        if (dlgLoadingWired != null && dlgLoadingWired.isShowing()) {
            dlgLoadingWired.dismiss();
        }
    }

    private ArrayList<String> getListOfWifiNetworks() {
        ArrayList<String> oneUpWifis = new ArrayList<>();
        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (wifiManager != null) {
            // Start scanning for Wi-Fi networks
            wifiManager.startScan();
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                data.showErrorDlg("Can't scan wifi networks. Did you enable all permissions?", MainActivity.this);
                return null;
            }
            List<ScanResult> scanResults = wifiManager.getScanResults(); // Get the scan results

            Log.d(TAG,"--Scanning Wifi--");
            // Process the scan results
            for (ScanResult result : scanResults) {
                String networkName = result.SSID; // Network name (SSID)
                String bssid = result.BSSID; // Network MAC address
                int signalLevel = WifiManager.calculateSignalLevel(result.level, 5); // Signal level// Do something with the network information
                Log.d(TAG,"Network Name: " + networkName);
                if (networkName.contains(WIFI_PREFIX)){
                    oneUpWifis.add(networkName);
                }
            }
            return oneUpWifis;
        }

        return  null;
    }
    public void connectToWifi(String wifiName, String password){

        //Toast.makeText(this, "Connecting to timer module...", Toast.LENGTH_SHORT).show();
        WifiNetworkSpecifier.Builder builder = new WifiNetworkSpecifier.Builder();
        builder.setSsid(wifiName);
        if (password == null) {
            builder.setWpa2Passphrase(WIFI_PASS);
        } else{
            builder.setWpa2Passphrase(password);
        }

        WifiNetworkSpecifier wifiNetworkSpecifier = builder.build();

        NetworkRequest.Builder networkRequestBuilder1 = new NetworkRequest.Builder();
        networkRequestBuilder1.addTransportType(NetworkCapabilities.TRANSPORT_WIFI);
        networkRequestBuilder1.setNetworkSpecifier(wifiNetworkSpecifier);

        if (networkCallback != null) {
            connectivityManager.unregisterNetworkCallback(networkCallback);
        }

        if (dlgConnecting.isShowing()){
            dlgConnecting.showConnecting();
        }
        Log.d(TAG, "Connecting to " + wifiName + ":" + password + ":::");
        NetworkRequest nr = networkRequestBuilder1.build();
        connectivityManager = (ConnectivityManager) getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        networkCallback = new ConnectivityManager.NetworkCallback() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAvailable(Network network) {
                super.onAvailable(network);
                Log.d(TAG, "onAvailable:" + getCurrentWifiSSID());
                //Toast.makeText(MainActivity.this, "Connected to timer module!", Toast.LENGTH_SHORT).show();

                connectivityManager.bindProcessToNetwork(network);
                //connect to the websocket
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {dlgConnecting.showOpenWebsocket();}   });

                reconnectWebsocket(WEBSOCKET_WIFI_ADD);

            }

            @Override
            public void onLost(@NonNull Network network) {
                // This method is called when the network is lost
                // Disconnect from the network
                Log.d(TAG, "Wifi connection lost");

            }
        };
        connectivityManager.requestNetwork(nr, networkCallback);
    }

    public void connectToEthernet() {
        //check for ethernet capability
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        Network[] networks = cm.getAllNetworks();
        boolean foundEth = false;
        for (Network network : networks) {
            NetworkCapabilities capabilities = cm.getNetworkCapabilities(network);
            if (capabilities != null && capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
                // Ethernet is available
               foundEth = true;
               break;
            }
            if (capabilities != null && capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                // Ethernet is available
                showToast("Wifi capable");
            }
            if (capabilities != null && capabilities.hasTransport(NetworkCapabilities.TRANSPORT_USB)) {
                // Ethernet is available
                showToast("USB capable");
            }

        }

        if (!foundEth){
            showToast("Ethernet not capable");
            //return;
        }


        //Log.d(TAG, "Requesting Ethernet network");
        showToast("Requesting Ethernet network");

        // Create a NetworkRequest for Ethernet transport type
        NetworkRequest.Builder networkRequestBuilder = new NetworkRequest.Builder();
        networkRequestBuilder.addTransportType(NetworkCapabilities.TRANSPORT_USB);

        // Optionally add other capabilities or constraints if needed
        networkRequestBuilder.addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        networkRequestBuilder.addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_RESTRICTED);
        networkRequestBuilder.addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED);

        NetworkRequest networkRequest = networkRequestBuilder.build();
        connectivityManager = (ConnectivityManager) getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);

        if (networkCallback != null) {
            connectivityManager.unregisterNetworkCallback(networkCallback);
        }

        networkCallback = new ConnectivityManager.NetworkCallback() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onAvailable(Network network) {
                super.onAvailable(network);
                Log.d(TAG, "Ethernet onAvailable: " + network);
                showToast("Ethernet onAvailable: " + network);
                connectivityManager.bindProcessToNetwork(network);
                reconnectWebsocket(WEBSOCKET_ETH0_ADD);
            }

            @Override
            public void onLost(@NonNull Network network) {
                Log.d(TAG, "Ethernet connection lost");
                showToast("Ethernet connection lost");
            }

            @Override
            public void onUnavailable() {
                Log.d(TAG, "Ethernet connection unavailable");
                showToast("Ethernet connection unavailable");
            }
        };

        connectivityManager.requestNetwork(networkRequest, networkCallback);
    }

    private void disconnectWebsocket(){
        if (data.ws_() != null) {
            data.ws_().close(1000, "Websocket connection closed");

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    data.ws.setValue(null);
                    data.openWebsocket.setValue(false);
                    updateConnectionDot(false);}});
        }
    }

    private void getIpAddress(){
        // Function to get the device's IP address

            try {
                // Get all network interfaces
                List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
                for (NetworkInterface networkInterface : interfaces) {
                    // Check for Ethernet interface (usually named eth0)
                    if (networkInterface.getName().equalsIgnoreCase("eth0") || networkInterface.getName().equalsIgnoreCase("wlan0")) {
                        List<InetAddress> addresses = Collections.list(networkInterface.getInetAddresses());
                        for (InetAddress address : addresses) {
                            // Check if the address is an IPv4 address
                            if (address instanceof Inet4Address && !address.isLoopbackAddress()) {
                                String ipAddress = address.getHostAddress();
                                //Toast.makeText(this, "IP Address: " + ipAddress, Toast.LENGTH_LONG).show();
                                return;
                            }
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        Toast.makeText(this, "Unable to get IP Address", Toast.LENGTH_LONG).show();

    }
    public void reconnectWebsocket(String add) {
        if (data.ws_() != null) {
            data.ws_().close(1000, "Websocket connection closed");

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    data.ws.setValue(null);
                    data.openWebsocket.setValue(false);
                    updateConnectionDot(false);}});
        }


        //createWebSocketClient("ws://" + nodeName + ".local/ws");
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder().url(add).build();
        MyWebSocketListener listener = new MyWebSocketListener();
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                
                data.ws.setValue(client.newWebSocket(request, listener));
                //Toast.makeText(MainActivity.this, "Connected to Timer Module!", Toast.LENGTH_SHORT).show();
                getIpAddress();
            }
        });
    }

    public void disconnectWifi() {
        if (data.ws_() != null) {
            data.ws_().close(1000, "Websocket connection closed");
        }
        if (connectivityManager != null) {
            connectivityManager.unregisterNetworkCallback(networkCallback);
        }
        // Disconnect from the current Wi-Fi network
        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        if (wifiManager != null) {
            wifiManager.disconnect();
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            boolean allPermissionsGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false;
                    break;
                }
            }

            if (!allPermissionsGranted){
                new AlertDialog.Builder(this)
                        .setTitle("Permissions Required")
                        .setMessage("You have denied some permissions permanently. Please go to settings and enable them manually.\nCamera is required to scan QRCode for connection.\nLocation is required to connect to the device via Wifi.")
                        .setPositiveButton("Go to Settings", (dialog, which) -> {
                            // Open app settings
                            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.fromParts("package", getPackageName(), null));
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        })
                        .setNegativeButton("Cancel", (dialog, which) -> {
                            // Handle cancel action if needed
                        })
                        .create()
                        .show();


            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            String scannedData = data.getStringExtra("scannedData");
            // Handle the scanned data (e.g., display it in a TextView)
            Log.d(TAG,scannedData);
            String ssid = scannedData.split(",")[0].split(":")[1];
            String pass = scannedData.split(",")[1].split(":")[1];
            dlgConnecting.setEdtPassword(pass);
            connectToWifi(ssid,pass);

        }
    }


    private void showToast(String msg) {

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
            }
        });
    }
    private String getCurrentWifiSSID() {
        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
        if (wifiInfo != null && wifiInfo.getSSID() != null) {
            return wifiInfo.getSSID().replace("\"", ""); // Remove quotes if SSID has them
        }
        return null;
    }

    @Override
    protected void onStart() {
        super.onStart();
        //set custom toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbarText = findViewById(R.id.toolbar_event_details);
        toolbarText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Log.d(TAG,"Clicked event");
                DialogEventDetails dlg = new DialogEventDetails(MainActivity.this, new DialogEventDetails.DialogEventDetailsMethods() {
                    @Override
                    public void onConfirm(String event_name, String event_descr) {
                        data.getConfig().getValue().setEvent_name(event_name);
                        data.getConfig().getValue().setEvent_descr(event_descr);
                        data.saveConfig(MainActivity.this);
                        toolbarText.setText(data.getConfig().getValue().getToolbarText());
                    }
                });
            }
        });
        toolbarText.setText(data.getConfig().getValue().getToolbarText());
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Register the BroadcastReceiver to listen for Wi-Fi network connectivity events
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        intentFilter.addAction(WifiManager.SUPPLICANT_STATE_CHANGED_ACTION);
        intentFilter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);

        registerReceiver(wifiConnectivityReceiver, intentFilter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Unregister the BroadcastReceiver to stop listening for Wi-Fi network connectivity events
        unregisterReceiver(wifiConnectivityReceiver);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (wifiReceiver != null) {
            unregisterReceiver(wifiReceiver);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        this.menu_main = menu;
        return true;
    }

    private void showDisconnectDialog(){
        DialogDisconnect dlg = new DialogDisconnect(this, new DialogDisconnect.DialogDisconnectMethods() {
            @Override
            public void onDisconnect() {
                data.sendWebMsg("disconnect");
                disconnectWebsocket();
                if (curTimer != null){
                    curTimer = null;
                    stopTimer2();
                    deselectTimer();
                }
                //disconnectWifi();
            }

            @Override
            public void onShutdown() {
                data.sendWebMsg("shutdown");
            }
        });
    }

    void promptToChangeWifiStatus(boolean shouldBeOn){
        //set the message
        String msg = "Wifi is on and it needs to be turned off for a wired connection.\n\nAfter you have connected via wire, please wait until you see the logo in the top status bar before trying to connect.";
        if (shouldBeOn){
            msg = "Wifi is off and it needs to be turned on for a wireless connection";
        }
        new AlertDialog.Builder(this)
                .setTitle("Wifi State Change")
                .setMessage(msg)
                .setPositiveButton("Go to Settings", (dialog, which) -> {
                    // Show the Wi-Fi settings panel to the user
                    Intent panelIntent = new Intent(Settings.ACTION_WIFI_SETTINGS);
                    startActivity(panelIntent);
                })
                .setNegativeButton("Cancel", (dialog, which) -> {
                    // Handle cancel action if needed
                })
                .create()
                .show();
    }

    private void ensureEthernetConnection(){

        showLoadingWired();
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkRequest.Builder request = new NetworkRequest.Builder();
        request.addTransportType(NetworkCapabilities.TRANSPORT_ETHERNET);

        connectivityManager.registerNetworkCallback(request.build(), new ConnectivityManager.NetworkCallback() {
            @Override
            public void onAvailable(Network network) {
                // Ethernet is available, bind the network
                connectivityManager.bindProcessToNetwork(network);
                reconnectWebsocket(WEBSOCKET_ETH0_ADD);
                dismissLoadingWired();
            }

            @Override
            public void onLost(Network network) {
                // Ethernet is lost
                Log.d("Network", "Ethernet disconnected");
            }
        });



    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == R.id.menu_btn_wireless) {

            if (!checkWifiOn()){
                promptToChangeWifiStatus(true);
                return true;
            }
            //if not connected show connecting
            if (!data.openWebsocket.getValue()) {
                dlgConnecting.show();
                //turn off the labels that may be shown already
                dlgConnecting.hideTexts();
                startWirelessConnection();
            } else{
                showDisconnectDialog();
            }

            return true;
        } else if (id == R.id.menu_btn_wired) {
            if (!data.openWebsocket.getValue()) {
                //TODO - turn off wifi
                if (checkWifiOn()){
                    promptToChangeWifiStatus(false);
                } else {
                    ensureEthernetConnection();
                }
            } else {
                showDisconnectDialog();
            }
            return true;
        } else if (id == R.id.menu_btn_blink_start){
            showDefaultBlinkStartDlg();
        } else if (id == R.id.menu_btn_blink_length){
            showBlinkLengthDlg();
        } else if (id == R.id.menu_clear_timers){
            for(ctTimer t : data.getTimers()){
                t.setTimeInSeconds(-1);
                //t.setBlinkTime(-1);
                t.setLabel("");
                refreshScreen();
            }
            data.getConfig().getValue().setEvent_name("Event");
            data.getConfig().getValue().setEvent_descr("Description");
            data.saveConfig(MainActivity.this);
            toolbarText.setText(data.getConfig().getValue().getToolbarText());

        } else if (id == R.id.menu_help){
            Intent i = new Intent(MainActivity.this,Help.class);
            startActivity(i);
        } else if (id == R.id.menu_update_firmware){

            if (!data.openWebsocket.getValue()){
                Toast.makeText(this, "Need to connect to timer before updating firmware", Toast.LENGTH_SHORT).show();
                return true;
            }
            try {
                send_latest_firmware("oneUpTimer_v" + VERSION_NUM + ".py");
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        return super.onOptionsItemSelected(item);
    }

    //--ANDREI UPDATE
    void send_latest_firmware( String fileName) throws Exception {
            byte[] fileBytes = readFileToByteArray(fileName);

            // Calculate checksum
            String checksum = getSHA256Checksum(fileBytes);

            // Send metadata
            JSONObject metadata = new JSONObject();
            metadata.put("filename", fileName);
            metadata.put("size", fileBytes.length);
            metadata.put("checksum",checksum);
            metadata.put("version",VERSION_NUM);
            data.ws.getValue().send(metadata.toString());

            // Send file in chunks
            int chunkSize = 4096;
            for (int i = 0; i < fileBytes.length; i += chunkSize) {
                int end = Math.min(fileBytes.length, i + chunkSize);
                byte[] chunk = new byte[end - i];
                System.arraycopy(fileBytes, i, chunk, 0, end - i);
                data.ws.getValue().send(ByteString.of(chunk));
            }

            // Send EOF signal
            data.ws.getValue().send("{\"EOF\": true}");
        }


    // Read file into byte array (compatible with API 29+)
    private byte[] readFileToByteArray(String fileName) throws IOException {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        InputStream inputStream = MainActivity.this.getAssets().open(fileName);
        //BufferedInputStream inputStream = new BufferedInputStream(new FileInputStream(file));
        byte[] buffer = new byte[4096];
        int bytesRead;

        while ((bytesRead = inputStream.read(buffer)) != -1) {
            outputStream.write(buffer, 0, bytesRead);
        }

        inputStream.close();
        return outputStream.toByteArray();
    }
// Helper function to get SHA-256 checksum
private String getSHA256Checksum(byte[] fileBytes) throws Exception {
    MessageDigest digest = MessageDigest.getInstance("SHA-256");
    byte[] hash = digest.digest(fileBytes);
    StringBuilder hexString = new StringBuilder();
    for (byte b : hash) {
        hexString.append(String.format("%02x", b));  // Convert byte to hex
    }
    return hexString.toString();  // Return hex string checksum
}
    //--END ANDREI UPDATE

    void showBlinkLengthDlg(){
        String curLength = data.secondsToText(data.getConfig().getValue().getBlinkLength());
        DialogInputTime i = new DialogInputTime(this, new DialogInputTime.DialogInputTimeMethods() {
            @Override
            public void onConfirm(String time) {
                int mins = Integer.parseInt(time.split(":")[0]);
                int secs = Integer.parseInt(time.split(":")[1]);
                int totalTime = (mins*60) + secs;
                data.getConfig().getValue().setBlinkLength(totalTime);
                data.saveConfig(MainActivity.this);
                //send to rpi
                data.sendWebMsg("blink_length:"+totalTime);

            }
        }, curLength );
    }

    void showDefaultBlinkStartDlg(){
        DialogInputTime i = new DialogInputTime(this, new DialogInputTime.DialogInputTimeMethods() {
            @Override
            public void onConfirm(String time) {
                int mins = Integer.parseInt(time.split(":")[0]);
                int secs = Integer.parseInt(time.split(":")[1]);
                int totalTime = (mins*60) + secs;
                ArrayList<ctTimer> timers = data.lstTimers.getValue();
                for(ctTimer t : timers){
                    t.setBlinkTime(totalTime);
                }
                data.lstTimers.setValue(timers);

                data.saveTimers(MainActivity.this);
                //if a timer is selected update it
                if (curTimer != null){
                    curTimer = data.lstTimers.getValue().get(idxTimer);
                    //TODO check if the timer is running because we need to send the new blink start time
                    if (timer != null){
                        data.sendWebMsg("blink_start:"+curTimer.getBlinkTime());
                    }
                }
                refreshScreen();

            }
        },null);
    }

    private void deselectTimer(){
        curTimer = null;
        //reset the active timer to nothing
        binding.txtActiveTimer.setTextColor(getResources().getColor(R.color.black));
        binding.btnStart.setText("Start");
        //reset the active timer to the current timer selected
        binding.txtActiveTimer.setText("");
        binding.lblActiveTimerLabel.setText("");
        binding.btnStart.setEnabled(false);
        binding.btnStop.setEnabled(false);
    }

    public void updateConnectionDot(boolean isConnected) {
        if (menu_main != null) {
            // Access the menu item
            MenuItem connectionItem = menu_main.findItem(R.id.menu_connection);

            // Change the icon based on the connection status
            if (isConnected) {
                connectionItem.setIcon(R.drawable.dot_green);
            } else {
                connectionItem.setIcon(R.drawable.dot_red);
            }
        }
    }


    private final BroadcastReceiver wifiConnectivityReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            //if the network state changed
            if (WifiManager.NETWORK_STATE_CHANGED_ACTION.equals(action)) {
                NetworkInfo networkInfo = intent.getParcelableExtra(WifiManager.EXTRA_NETWORK_INFO);
                if (networkInfo == null) {
                    return;
                }

                if (networkInfo.getState() == NetworkInfo.State.CONNECTED) {
                    WifiManager wifiManager = (WifiManager) MainActivity.this.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    WifiInfo wifiInfo = wifiManager.getConnectionInfo();
                    // Device is connected to a Wi-Fi network
                    Log.d(TAG, "Device connected to Wi-Fi network: " + wifiInfo.getSSID());

                    //Toast.makeText(context, "Device connected to " + wifiInfo.getSSID(), Toast.LENGTH_LONG).show();
                    //data.connectedWifi.setValue(wifiInfo.getSSID());
                } else if (networkInfo.getState() == NetworkInfo.State.DISCONNECTED) {
                    // Device is not connected to a Wi-Fi network
                    Log.d(TAG, "Device not connected to Wi-Fi network");
                    //Toast.makeText(context, "Could not connect to wifi", Toast.LENGTH_SHORT).show();
                    //data.connectedWifi.setValue("");
                }
            } else if (WifiManager.SUPPLICANT_STATE_CHANGED_ACTION.equals(action)) {
                SupplicantState supplicantState = intent.getParcelableExtra(WifiManager.EXTRA_NEW_STATE);
                int supplicantError = intent.getIntExtra(WifiManager.EXTRA_SUPPLICANT_ERROR, -1);
                if (supplicantState == SupplicantState.COMPLETED) {
                    // Wi-Fi authentication succeeded and the device has connected to the network
                    Log.d(TAG, "Wi-Fi authentication succeeded and device connected to network");
                } else if (supplicantState == SupplicantState.DISCONNECTED) {
                    // Wi-Fi authentication failed or the connection was lost
                    Log.d(TAG, "Wi-Fi authentication failed or connection lost");
                    // Wi-Fi authentication failed
                    if (supplicantError == WifiManager.ERROR_AUTHENTICATING) {
                        Log.e(TAG, "Wi-Fi authentication failed. Check your credentials.");
                        Toast.makeText(context, "Authentication failed. Check Wi-Fi credentials.", Toast.LENGTH_LONG).show();
                    } else {
                        Log.d(TAG, "Wi-Fi connection lost.");
                    }
                }
            } else if (WifiManager.WIFI_STATE_CHANGED_ACTION.equals(action)) {
                int wifiState = intent.getIntExtra(WifiManager.EXTRA_WIFI_STATE, WifiManager.WIFI_STATE_UNKNOWN);
                if (wifiState == WifiManager.WIFI_STATE_DISABLED) {
                    // The Wi-Fi has been disabled
                    //Toast.makeText(context, "Wifi is disabled", Toast.LENGTH_SHORT).show();
                } else  if (wifiState == WifiManager.WIFI_STATE_ENABLED) {
                    // The Wi-Fi has been disabled
                    //Toast.makeText(context, "Wifi is enabled", Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

    private void checkPermissions() {
        // Request permissions
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_WIFI_STATE) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.CHANGE_WIFI_STATE) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.INTERNET) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.CHANGE_NETWORK_STATE) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_NETWORK_STATE) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
        {

            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_WIFI_STATE,
                    Manifest.permission.CHANGE_WIFI_STATE,
                    Manifest.permission.CHANGE_NETWORK_STATE,
                    Manifest.permission.ACCESS_NETWORK_STATE,
                    Manifest.permission.INTERNET,
                    Manifest.permission.CAMERA
            }, REQUEST_PERMISSIONS);
        }
    }

    public class MyWebSocketListener extends WebSocketListener {
        @Override
        public void onOpen(WebSocket webSocket, Response response) {
            // WebSocket connection opened
            Log.d(TAG, "Websocket opened");
            data.sendWebMsg("init");
        }

        @Override
        public void onMessage(WebSocket webSocket, String s) {
            // Received message from server
            Log.d(TAG, "Message received:" + s);
            final String message = s;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        parseWebCMD(message);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Log.d(TAG, "Exception: " + e.getMessage());
                    }
                }
            });
        }

        @Override
        public void onClosing(WebSocket webSocket, int code, String reason) {
            // WebSocket connection closing
            showToast("Websocket Closed ");
            Log.d(TAG, "Websocket closed: " + reason);
            webSocket.close(code,reason);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {data.openWebsocket.setValue(false);
                    updateConnectionDot(false);
                }   });
        }

        @Override
        public void onFailure(WebSocket webSocket, Throwable t, Response response) {
            // WebSocket connection failure
                Log.d(TAG,"Websocket failure");
                runOnUiThread(new Runnable() {
                @Override
                public void run() { updateConnectionDot(false);
                    data.ws.setValue(null);
                    data.openWebsocket.setValue(false);
                    data.showErrorDlg("Connection to timer module dropped!",MainActivity.this);
                    if (dlgConnecting.isShowing()){
                        dlgConnecting.close();
                    }
                    disconnectWifi();
                    stopTimer2();
                    curTimer = null;
                    deselectTimer();

                }});

                if (t.getMessage() != null) {
                    Log.d(TAG, t.getMessage());
                    showToast("Error WebSocket Not Connected: " + t.getMessage());
                }



               /* runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        data.openWebsocket.setValue(false);

                        //TODO this shouldn't show if they click disconnect? or maybe leave it so they know it worked?
                        //showToast("Lost connection! Go to the Home Page to reconnect");
                        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(MainActivity.this);
                        builder.setTitle("Error: Lost Connection");
                        builder.setMessage("Press ok to go to the Settings page to reconnect");
                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // Do something when OK button is clicked
                                dialog.dismiss();
                            }
                        });
                        AlertDialog dialog = builder.create();
                        dialog.show();

                    }
                });*/
            }
        }

    private void logLayoutVersion(){
        // Get the current configuration
        Configuration config = getResources().getConfiguration();
        String layoutQualifier = "";

        // Check screen orientation
        if (config.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            layoutQualifier += "land";
        }

        // Check screen size
        int screenSize = config.screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK;
        switch (screenSize) {
            case Configuration.SCREENLAYOUT_SIZE_SMALL:
                layoutQualifier += "-small";
                break;
            case Configuration.SCREENLAYOUT_SIZE_NORMAL:
                layoutQualifier += "-normal";
                break;
            case Configuration.SCREENLAYOUT_SIZE_LARGE:
                layoutQualifier += "-large";
                break;
            case Configuration.SCREENLAYOUT_SIZE_XLARGE:
                layoutQualifier += "-xlarge";
                break;
            default:
                layoutQualifier += "-undefined";
                break;
        }

        // Log the inferred layout being used
        Log.d(TAG, "Inferred layout: activity_main " + layoutQualifier);

        // Get display metrics
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

        float density = displayMetrics.density; // This gives you the density scale
        int widthPixels = displayMetrics.widthPixels;
        int heightPixels = displayMetrics.heightPixels;

// Calculate dp
        int widthDp = (int) (widthPixels / density);
        int heightDp = (int) (heightPixels / density);

// Log the results
        Log.d("USER_DEV", "Width: " + widthPixels + "px, Height: " + heightPixels + "px");
        Log.d("USER_DEV", "Width in DP: " + widthDp + "dp, Height in DP: " + heightDp + "dp");
        Log.d("USER_DEV", "Density: " + density);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }


}