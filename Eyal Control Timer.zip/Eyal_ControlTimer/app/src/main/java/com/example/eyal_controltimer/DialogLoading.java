package com.example.eyal_controltimer;

import android.app.Dialog;
import android.content.Context;
import android.os.Handler;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;


public class DialogLoading extends Dialog {

    private TextView messageTextView;
    private ProgressBar progressBar;
    private Handler handler;
    private Runnable updateMessageRunnable;
    private String startMsg;

    public DialogLoading(@NonNull Context context) {
        super(context);
        setContentView(R.layout.dlg_loading_wired);
        messageTextView = findViewById(R.id.txtLoadingWired);
        progressBar = findViewById(R.id.prgLoadingWired);
        handler = new Handler();

        startMsg = "Waiting to register wired connection...\n" +
                "You should see an icon in the top status bar when\nwired connection is recognized";
        // Set initial message
        messageTextView.setText(startMsg);

        // Define the runnable to update the message after 30 seconds
        updateMessageRunnable = new Runnable() {
            @Override
            public void run() {
                updateMessage("It's been over 30 seconds. Please check your wired connection.");
            }
        };
    }

    // Method to update the message text
    public void updateMessage(String message) {
        messageTextView.setText(message);
    }

    @Override
    public void show() {
        super.show();
        // Reset the message to the initial state
        messageTextView.setText(startMsg);

        // Re-register the 30-second delay handler
        handler.postDelayed(updateMessageRunnable, 30000); // 30 seconds
    }

    // Method to dismiss the dialog
    @Override
    public void dismiss() {
        super.dismiss();
        handler.removeCallbacksAndMessages(null); // Cancel any pending message updates
    }
}
