package com.example.eyal_controltimer;

import static com.example.eyal_controltimer.DataViewModel.LOG_TAG;

import android.app.Dialog;
import android.content.Context;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class DialogInputTime {

    public interface DialogInputTimeMethods{
        void onConfirm(String time);
    }

    DialogInputTimeMethods methods;
    Context c;
    private Dialog dialog;

    private Button btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btn0,btnOk;
    private ImageButton btnBackspace, btnClose;
    private String time = "";
    private TextView t1,t2,t3,t4;
    private TextView tArray[];

    public DialogInputTime(Context c, DialogInputTimeMethods methods, String timeToDisplay){
        this.methods = methods;
        this.c = c;
        dialog = new Dialog(c);
        dialog.setContentView(R.layout.dlg_time_input);
        //set the dialog background to transparent so you only see the constraint layout background
        //the problem was that the constraint was rounded but the actual dialog had square corners
        //dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        btn0 = dialog.findViewById(R.id.btn0);
        btn1 = dialog.findViewById(R.id.btn1);
        btn2 = dialog.findViewById(R.id.btn2);
        btn3 = dialog.findViewById(R.id.btn3);
        btn4 = dialog.findViewById(R.id.btn4);
        btn5 = dialog.findViewById(R.id.btn5);
        btn6 = dialog.findViewById(R.id.btn6);
        btn7 = dialog.findViewById(R.id.btn7);
        btn8 = dialog.findViewById(R.id.btn8);
        btn9 = dialog.findViewById(R.id.btn9);

        t1 = dialog.findViewById(R.id.txt1);
        t2 = dialog.findViewById(R.id.txt2);
        t3 = dialog.findViewById(R.id.txt3);
        t4 = dialog.findViewById(R.id.txt4);
        tArray = new TextView[4];
        tArray[0] = t1;
        tArray[1] = t2;
        tArray[2] = t3;
        tArray[3] = t4;
        setupButtonListeners();

        if (timeToDisplay != null){
            //remove the semicolon
            timeToDisplay = timeToDisplay.replace(":","");
            time = timeToDisplay;
            //put into display textviews
            for(int i = 0; i < timeToDisplay.length(); i++){
                tArray[i].setText("" + timeToDisplay.charAt(i));
            }
        }

        btnOk = dialog.findViewById(R.id.btnOk);
        btnBackspace = dialog.findViewById(R.id.btnBackspace);
        btnClose = dialog.findViewById(R.id.imgCloseEventDetails);

        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //check length
                if (time.length() != 4){
                    Toast.makeText(c, "Please enter 4 digits", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (methods != null){
                    //put the semicolon in
                    time = time.substring(0,2) + ":" + time.substring(2);
                    Log.d(LOG_TAG,"Time: " + time);
                    methods.onConfirm(time);
                    dialog.cancel();
                }

            }
        });

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.cancel();
            }
        });

        btnBackspace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (time.isEmpty()){
                    return;
                }

                if (time.length() == 1){
                    time = "";
                } else {
                    time = time.substring(0, time.length() - 1);
                }
                setTimeText();
            }
        });



        dialog.show();
    }

    private View.OnClickListener clickNumber = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if (time.length() == 4){
                return;
            }

            String num = ((Button)view).getText().toString();
            //TODO
            //error check for a bad time, this should maybe happen on okay
            time += num;
            setTimeText();
        }
    };

    private void setTimeText(){

        //clear all
        for(int i = 0; i < tArray.length; i++){
            tArray[i].setText("");
        }

        for(int i = 0; i < time.length(); i++){
            tArray[i].setText("" + time.charAt(i));
        }
    }

    private void setupButtonListeners(){
        btn1.setOnClickListener(clickNumber);
        btn2.setOnClickListener(clickNumber);
        btn3.setOnClickListener(clickNumber);
        btn4.setOnClickListener(clickNumber);
        btn5.setOnClickListener(clickNumber);
        btn6.setOnClickListener(clickNumber);
        btn7.setOnClickListener(clickNumber);
        btn8.setOnClickListener(clickNumber);
        btn9.setOnClickListener(clickNumber);
        btn0.setOnClickListener(clickNumber);
    }
}
