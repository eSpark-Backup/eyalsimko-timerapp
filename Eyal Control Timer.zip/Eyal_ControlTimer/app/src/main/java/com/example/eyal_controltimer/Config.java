package com.example.eyal_controltimer;

import org.json.JSONException;
import org.json.JSONObject;



public class Config {
    public static final String JSON_BLINK_LENGTH = "blinkLength";
    private int blinkLength = 0;
    private String event_name;
    private String event_descr;

    public Config(){
        this.blinkLength = 10;
        this.event_name = "Event Name";
        this.event_descr = "Description";
    }

    public Config(int blinkLength, String event_name, String event_descr) {
        this.blinkLength = blinkLength;
        this.event_name = event_name;
        this.event_descr = event_descr;
    }

    public String getEvent_name() {
        return event_name;
    }

    public void setEvent_name(String event_name) {
        this.event_name = event_name;
    }

    public String getEvent_descr() {
        return event_descr;
    }

    public void setEvent_descr(String event_descr) {
        this.event_descr = event_descr;
    }

    public int getBlinkLength() {
        return blinkLength;
    }

    public void setBlinkLength(int blinkLength) {
        this.blinkLength = blinkLength;
    }

    public String getToolbarText(){
        return event_name + ":" + event_descr;
    }
    public Config(JSONObject j) throws JSONException {
        blinkLength = j.getInt(JSON_BLINK_LENGTH);
    }

    public JSONObject toJSONObject() throws JSONException{
        JSONObject out = new JSONObject();
        out.put(JSON_BLINK_LENGTH,blinkLength);
        return out;
    }

    @Override
    public String toString() {
        return "Config{" +
                "blinkLength=" + blinkLength +
                ", event_name='" + event_name + '\'' +
                ", event_descr='" + event_descr + '\'' +
                '}';
    }
}
