package com.example.eyal_controltimer;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.eyal_controltimer.R;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.journeyapps.barcodescanner.CaptureActivity;

public class QRCodeScanner extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrcode_scanner);

        // Start the QR code scanner
        startQRCodeScanner();
    }

    private void startQRCodeScanner() {
        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE);
        integrator.setPrompt("Scan a QR Code");
        integrator.setOrientationLocked(false);
        integrator.setBeepEnabled(true);
        integrator.setCaptureActivity(CaptureActivity.class);
        integrator.initiateScan();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);

        /*if (resultCode == RESULT_OK){
            String scannedData = data.getExtras().getString("scannedData");
            // Handle the scanned data (e.g., display it, send it back to another activity)
            Intent resultIntent = new Intent();
            resultIntent.putExtra("scannedData", scannedData);
            setResult(RESULT_OK, resultIntent);
            finish(); // Close the scanner activity
        }*/

        if (result != null) {
            if (result.getContents() != null) {
                // QR code successfully scanned
                String scannedData = result.getContents();
                // Handle the scanned data (e.g., display it, send it back to another activity)
                Intent resultIntent = new Intent();
                resultIntent.putExtra("scannedData", scannedData);
                setResult(RESULT_OK, resultIntent);
                finish(); // Close the scanner activity
            } else {
                // Handle scan failure or cancellation
                setResult(RESULT_CANCELED);
                finish();
            }
        }
    }
}
