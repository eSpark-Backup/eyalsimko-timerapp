package com.example.eyal_controltimer;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class DialogEventDetails {


        public interface DialogEventDetailsMethods{
            void onConfirm(String event_name, String event_descr);
        }

        DialogEventDetailsMethods methods;
        Context c;
        private Dialog dialog;

        private Button btnOk;
    private ImageButton btnClose;
        private EditText edtName, edtDescription;

        public DialogEventDetails(Context c, DialogEventDetailsMethods methods) {
            this.methods = methods;
            this.c = c;
            dialog = new Dialog(c);
            dialog.setContentView(R.layout.dlg_event_details);

            btnOk = dialog.findViewById(R.id.btnOk_EventDetails);
            btnClose = dialog.findViewById(R.id.imgCloseEventDetails);
            edtName = dialog.findViewById(R.id.edtEventName);
            edtDescription = dialog.findViewById(R.id.edtEventDescr);

            btnOk.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (methods != null){
                        String name = edtName.getText().toString();
                        String descr = edtDescription.getText().toString();
                        if (name.isEmpty() || descr.isEmpty()){
                            Toast.makeText(c, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        methods.onConfirm(name,descr);
                        dialog.cancel();
                    }
                }
            });

            btnClose.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dialog.cancel();
                }
            });

            dialog.show();
        }
}
