package com.example.eyal_controltimer;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class DialogDisconnect {

    public interface DialogDisconnectMethods{
        void onDisconnect();
        void onShutdown();
    }

    private DialogDisconnectMethods methods;
    private Context c;
    private Dialog dialog;
    private Button btnDisconnect, btnShutdown;
    private ImageButton btnClose;
    public DialogDisconnect(Context c, DialogDisconnectMethods methods){
        this.methods = methods;
        this.c = c;
        dialog = new Dialog(c);
        dialog.setContentView(R.layout.dlg_disconnect);

        btnDisconnect = dialog.findViewById(R.id.btnDisconnect);
        btnShutdown = dialog.findViewById(R.id.btnShutdown);
        btnClose = dialog.findViewById(R.id.imgDisconnectClose);

        btnDisconnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (methods != null){
                    methods.onDisconnect();
                    dialog.cancel();
                }
            }
        });

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.cancel();
            }
        });

        btnShutdown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(methods != null){
                    methods.onShutdown();
                    dialog.cancel();
                }
            }
        });

        dialog.show();

    }
}
