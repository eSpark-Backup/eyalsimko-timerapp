package com.example.eyal_controltimer;

import android.os.Bundle;
import android.text.Html;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toolbar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.eyal_controltimer.databinding.ActivityHelpBinding;

public class Help extends AppCompatActivity {

    private ActivityHelpBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHelpBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.lblHiddenMenu.setText(Html.fromHtml(getString(R.string.help_hidden_menu), Html.FROM_HTML_MODE_LEGACY));
        binding.lblCustomMessage.setText(Html.fromHtml(getString(R.string.help_custommsg), Html.FROM_HTML_MODE_LEGACY));
        binding.lblSetupTimer.setText(Html.fromHtml(getString(R.string.help_setuptimer), Html.FROM_HTML_MODE_LEGACY));
        binding.btnHelpBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

}