package com.example.eyal_controltimer;


import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.util.Log;
import androidx.appcompat.app.AlertDialog;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import okhttp3.WebSocket;

public class DataViewModel extends ViewModel {

    private static final int MAX_TIMERS = 200;
    public static final String LOG_TAG = "USER_DEV";
    private static final String FILE_NAME_TIMERS = "timers.json";
    private static final String FILE_NAME_CONFIG = "config.json";

    public MutableLiveData<WebSocket> ws = new MutableLiveData<>();
    private MutableLiveData<Config> config = new MutableLiveData<>();
    public MutableLiveData<Boolean> openWebsocket = new MutableLiveData<>(false);
    public MutableLiveData<ArrayList<ctTimer>> lstTimers = new MutableLiveData<>();
    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback = null;


    public ArrayList<ctTimer> getTimers(){
        if (lstTimers.getValue() == null){
            lstTimers.setValue(new ArrayList<>());
        }
        return lstTimers.getValue();
    }

    public MutableLiveData<Config> getConfig(){
        if (config == null){
            config = new MutableLiveData<>();
            config.setValue(new Config());
        }
        return config;
    }

    public void deleteFiles(Context context){
        // Get the file directory for internal storage
        File fileDir = context.getFilesDir();

        // Create file objects
        File timersFile = new File(fileDir, FILE_NAME_TIMERS);
        File configFile = new File(fileDir, FILE_NAME_CONFIG);

        // Delete timers file if it exists
        if (timersFile.exists()) {
            if (timersFile.delete()) {
                Log.d(LOG_TAG, "Timers file deleted successfully.");
            } else {
                Log.d(LOG_TAG, "Failed to delete timers file.");
            }
        } else {
            Log.d(LOG_TAG, "Timers file does not exist.");
        }

        // Delete config file if it exists
        if (configFile.exists()) {
            if (configFile.delete()) {
                Log.d(LOG_TAG, "Config file deleted successfully.");
            } else {
                Log.d(LOG_TAG, "Failed to delete config file.");
            }
        } else {
            Log.d(LOG_TAG, "Config file does not exist.");
        }

    }

    public void saveTimers(Context context) {
        Gson gson = new Gson();
        String json = gson.toJson(lstTimers.getValue());

        try (FileOutputStream fos = context.openFileOutput(FILE_NAME_TIMERS, Context.MODE_PRIVATE);
             OutputStreamWriter osw = new OutputStreamWriter(fos)) {
            osw.write(json);
            Log.d(LOG_TAG,"--Saved timers--");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<ctTimer> loadTimers(Context context) {
        Gson gson = new Gson();
        ArrayList<ctTimer> timers = new ArrayList<>();

        try (FileInputStream fis = context.openFileInput(FILE_NAME_TIMERS);
             InputStreamReader isr = new InputStreamReader(fis)) {
            Type timerListType = new TypeToken<ArrayList<ctTimer>>() {}.getType();
            timers = gson.fromJson(isr, timerListType);
            lstTimers.setValue(timers);
            Log.d(LOG_TAG, "Timers loaded from file");
        }catch(FileNotFoundException e){
            //if the file doesn't exist create 50 timers
            ArrayList<ctTimer> defaultTimers = new ArrayList<>();
            for(int i = 0; i < MAX_TIMERS;i++){
                defaultTimers.add(new ctTimer("",-1,-1));
            }
            lstTimers.setValue(defaultTimers);
            Log.d(LOG_TAG,"Created default timer list");
            saveTimers(context);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return lstTimers.getValue();
    }

    public void saveConfig(Context context){

        Gson gson = new Gson();
        String json = gson.toJson(getConfig().getValue());

        try (FileOutputStream fos = context.openFileOutput(FILE_NAME_CONFIG, Context.MODE_PRIVATE);
             OutputStreamWriter osw = new OutputStreamWriter(fos)) {
            osw.write(json);
            Log.d(LOG_TAG,"--Saved Config--");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadConfig(Context context) {
        Gson gson = new Gson();

        try (FileInputStream fis = context.openFileInput(FILE_NAME_CONFIG);
             InputStreamReader isr = new InputStreamReader(fis)) {
            Type configType = new TypeToken<Config>() {}.getType();
            Config c = gson.fromJson(isr, configType);
            getConfig().setValue(c);
            Log.d(LOG_TAG, "Config: " + getConfig().getValue().toString());
        }catch(FileNotFoundException e){
            Log.d(LOG_TAG,"Config not found, making default...");
            Config c = new Config();
            getConfig().setValue(c);
            saveConfig(context);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
/*
    public void saveConfig(Context context) {

        try (FileOutputStream fos = context.openFileOutput(FILE_NAME_CONFIG, Context.MODE_PRIVATE);
             OutputStreamWriter osw = new OutputStreamWriter(fos)) {
            osw.write(config.getValue().toJSONObject().toString());
            Log.d(LOG_TAG,"--Saved Config--");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e){
            e.printStackTrace();
        }
    }

    public void loadConfig(Context context){
        try (FileInputStream fis = context.openFileInput(FILE_NAME_CONFIG);
             InputStreamReader isr = new InputStreamReader(fis)) {
            BufferedReader reader = new BufferedReader(isr);

                // Read the JSON from the file
                StringBuilder jsonBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    jsonBuilder.append(line);
                }

                JSONObject jsonObj = new JSONObject(jsonBuilder.toString());
                getConfig().setValue(new Config(jsonObj));

            Log.d(LOG_TAG, "--Loaded config from file--");
            Log.d(LOG_TAG, jsonObj.toString());
        }catch(FileNotFoundException e){
            //no file so setup default blink time
            getConfig().getValue().setBlinkLength(10);
            saveConfig(context);
            Log.d(LOG_TAG,"Created default config");
        } catch (IOException e){
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
*/

    public String secondsToText(int seconds) {
        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;

        // Format the minutes and seconds to ensure two digits for each
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }


    public void sendWebMsg(String cmd) {
        if (ws.getValue() != null) {
            ws.getValue().send(cmd);
            Log.d(LOG_TAG,"Sent cmd: " + cmd);
        } else {
            Log.d(LOG_TAG, "Websocket null: Couldn't send " + cmd);
        }
    }

    public WebSocket ws_(){
        if (ws == null){
            ws = new MutableLiveData<>();
        }
        return ws.getValue();
    }


   /* public String connectedWifi(){
        if (connectedWifi == null){
            connectedWifi = new MutableLiveData<>();
            connectedWifi.setValue("");
        }
        return connectedWifi.getValue();
    }*/



    public void showErrorDlg(String err, Context c) {
        AlertDialog.Builder builder = new AlertDialog.Builder(c);
        builder.setTitle("Error");
        builder.setMessage(err);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                // Do something when OK button is clicked
                dialog.dismiss();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();

    }

}
