package com.example.eyal_controltimer;

public class ctTimer {
    private String label;
    private int timeInSeconds;
    private int blinkTime;

    // Constructor
    public ctTimer(String label, int timeInSeconds, int blinkTime) {
        this.label = label;
        this.timeInSeconds = timeInSeconds;
        this.blinkTime = blinkTime;
    }

    // Getters and setters
    public String getLabel() { return label; }
    public void setLabel(String label) { this.label = label; }

    public int getTimeInSeconds() { return timeInSeconds; }
    public void setTimeInSeconds(int timeInSeconds) { this.timeInSeconds = timeInSeconds; }

    public int getBlinkTime() { return blinkTime; }
    public void setBlinkTime(int blinkTime) { this.blinkTime = blinkTime; }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;  // Check if both references are the same
        if (obj == null || getClass() != obj.getClass()) return false;  // Ensure obj is not null and is of the same classctTimerother= (ctTimer) obj;  // Cast obj to ctTimer// Compare all relevant fieldsreturn timeInSeconds == other.timeInSeconds &&

        ctTimer other = (ctTimer) obj;
        return blinkTime == other.blinkTime &&
                label.equals(other.label) && timeInSeconds == other.timeInSeconds;
    }

}

