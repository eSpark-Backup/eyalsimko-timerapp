package com.example.eyal_controltimer;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.google.zxing.ResultPoint;
import com.journeyapps.barcodescanner.BarcodeCallback;
import com.journeyapps.barcodescanner.BarcodeResult;
import com.journeyapps.barcodescanner.DecoratedBarcodeView;
import com.journeyapps.barcodescanner.CaptureActivity;
import com.journeyapps.barcodescanner.camera.CameraSettings;

import java.util.List;

public class CustomCaptureActivity extends CaptureActivity {

    private DecoratedBarcodeView barcodeScannerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_capture);  // Use the custom layout

        barcodeScannerView = findViewById(R.id.barcode_scanner);

        // Access and modify camera settings
        CameraSettings settings = barcodeScannerView.getBarcodeView().getCameraSettings();
        settings.setAutoFocusEnabled(true);  // Enable autofocus
        settings.setRequestedCameraId(0);    // Use rear camera (0 for rear, 1 for front)
        //settings.setScanInverted(true);
        settings.setContinuousFocusEnabled(true);
        settings.setExposureEnabled(false);
        //settings.setRequestedPreviewSize(1920, 1080);  // Set high resolution

        barcodeScannerView.getBarcodeView().setCameraSettings(settings);

        // Make sure to start the view's preview with laser enabled
        barcodeScannerView.setStatusText("Point at QR Code");  // Set prompt text
        barcodeScannerView.getViewFinder().setVisibility(View.VISIBLE);  // Ensure the viewfinder/laser is visible

        barcodeScannerView.initializeFromIntent(getIntent());  // Ensure the scanner view is initialized properly
        barcodeScannerView.decodeContinuous(new BarcodeCallback() {
            @Override
            public void barcodeResult(BarcodeResult result) {
                // Handle the scanned result here
                Log.d("BARCODE", result.toString());
                Intent resultIntent = new Intent();
                resultIntent.putExtra("scannedData", result.toString());
                setResult(RESULT_OK, resultIntent);
                finish(); // Close the scanner activity
            }

            @Override
            public void possibleResultPoints(List<ResultPoint> resultPoints) {
                // This is where the yellow dots are rendered
                //barcodeScannerView.getViewFinder().addPossibleResultPoints(resultPoints);
            }
        });
    }



    @Override
    protected void onResume() {
        super.onResume();
        // Resume scanning
        barcodeScannerView.resume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Pause scanning
        barcodeScannerView.pause();
    }
}
