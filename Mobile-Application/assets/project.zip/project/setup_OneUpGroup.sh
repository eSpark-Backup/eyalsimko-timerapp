#!/bin/bash

# Exit immediately on error
set -e

# Variables
USER="linaro"
USER_HOME="/home/$USER"
SCRIPT_FOLDER="OneUpGroup"
SCRIPT_PATH="$USER_HOME/$SCRIPT_FOLDER"
PYTHON_SCRIPT="$SCRIPT_PATH/pythonScript.py"
AUTOSTART_DIR="$USER_HOME/.config/autostart"
DESKTOP_FILE="$AUTOSTART_DIR/oneupgroup.desktop"

# Ensure script is run as root
if [[ $EUID -ne 0 ]]; then
    echo "Please run this script as root (e.g., with sudo)"
    exit 1
fi

echo "Installing required packages..."
apt update
apt install -y --allow-change-held-packages python3 python3-tk python3-pkg-resources python3-pip python3-pil.imagetk
pip3 install websockets
pip3 install qrcode[pil]

echo "Creating target directory if it doesn't exist..."
mkdir -p "$SCRIPT_PATH"

echo "Copying OneUpGroup folder to $SCRIPT_PATH..."
cp -r ./OneUpGroup/* "$SCRIPT_PATH/"

echo "Setting executable permissions..."
chmod +x "$PYTHON_SCRIPT"
find "$SCRIPT_PATH" -type f -name "*.sh" -exec chmod +x {} \;

echo "Creating autostart directory if it doesn't exist..."
mkdir -p "$AUTOSTART_DIR"

echo "Creating .desktop file for autostart..."
cat <<EOF > "$DESKTOP_FILE"
[Desktop Entry]
Type=Application
Name=OneUpGroup Script
Exec=python3 $PYTHON_SCRIPT
X-GNOME-Autostart-enabled=true
EOF

echo "Setting ownership..."
chown -R $USER:$USER "$SCRIPT_PATH"
chown -R $USER:$USER "$AUTOSTART_DIR"

echo "Setup complete. Rebooting..."
sleep 5
reboot
