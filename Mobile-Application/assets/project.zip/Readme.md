# OneUpGroup RK3566 Linux Setup Guide

This guide explains how to:

- Flash a Debian-based Linux image onto an RK3566 development board
- Deploy project files
- Set up a custom Python GUI script to run at boot


## 📁 Folder Structure
```
project/
├── setupScript.sh
└── OneUpGroup/
    ├── pythonScript.py
    ├── NextTime_just_logo.png
    └── web_config.txt
```

## 🛠️ Step 1: Flash Debian Image to RK3566 Board

1. **Install [rkDevTool](https://github.com/rockchip-linux/rkdeveloptool)**:
    - On Ubuntu:  
      ```bash
      sudo apt install libudev-dev libusb-1.0-0-dev git make gcc
      git clone https://github.com/rockchip-linux/rkdeveloptool.git
      cd rkdeveloptool
      make
      sudo cp rkdeveloptool /usr/local/bin/
      ```

2. **Put your RK3566 board into Loader mode** (usually via maskrom button + USB-OTG).

3. **Flash Debian image**:

    Image can be downloaded from [source](https://t.xmdlplus.com/fileRead/download?s=uvx26InU7%2FhcYjiyr0P2Hupdt5%2F9KvyhFGBWqa%2Fc0UwNJRKspTMqz5vE1CeZRz2YdJ6X0vlInwfYADnVAPooWuA05n78DBBIGz2MH0GR6AE%3D)

    ```bash
    sudo rkdeveloptool db rk356x_loader_xxx.bin
    sudo rkdeveloptool wl 0x0 path/to/debian-image.img
    sudo rkdeveloptool rd
    ```


## 📂 Step 2: Copy Files to Target System

1. **Transfer `project-root/` folder** to the RK3566 system (use SCP, USB, or SD card):
    ```bash
    scp -r project-root/ linaro@<rk3566-ip-address>:/home/linaro/
    ```

2. **Log into your RK3566 device**:
    ```bash
    ssh linaro@<rk3566-ip-address>
    ```


## 🔐 Step 3: Change Script Permissions

```bash
cd /home/linaro/project-root
chmod +x setup_OneUpGroup.sh
sudo ./setup_OneUpGroup.sh
```

## 🔐 Step 4: Run Script

Navigate to the folder containing setup script and run the script.

```bash
sudo ./setup_OneUpGroup.sh
```

This will install required packages to run the OneUpGroup GUI script and sets up service to start oneupgroup service at system startup
